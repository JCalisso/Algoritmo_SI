# Exercício 4 - Loop while com continue e break: 
# Faça um programa que informe se o valor da compra dos items Ovos, Leite, Café e Arroz 
# atingiram o limite de 20 reais disponiveis na conta.

itens: list = [('Ovo', 17.00), ('Leite', 5.0), ('Café', 4.50), ('Arroz', 7.90)]

carteira: float = 20
caixa: float = 0

for item, valor in itens:
    if ()