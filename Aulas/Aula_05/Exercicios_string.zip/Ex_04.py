
# Exercício 4: Capitalização de Texto
# Peça ao usuário para inserir uma frase e, em seguida, imprima a frase
# com todas as palavras começando com letras maiúsculas.

string_user = input('Insira uma frase: \n')
string_capitalized = string_user.title()

print(f'Sua frase ficou: {string_capitalized}')