first_number = float(input('Insira o primeiro número: '))
second_number = float(input('Insira o segundo número: '))
third_number = float(input('Insira o terceiro número: '))

mid: float = (first_number + second_number + third_number)/ 3

print(f'A média entre os 3 valores é {mid}')