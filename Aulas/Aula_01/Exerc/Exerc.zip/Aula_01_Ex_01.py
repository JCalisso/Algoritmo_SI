first_number = int(input('Insira o primeiro número: '))
second_number = int(input('Insira o segundo número: '))

print(f'A multplicação entre o {first_number} e o {second_number} é: {first_number * second_number}')

