first_number = int(input('Insira o primeiro número: '))
second_number = int(input('Insira o segundo número: '))

if (first_number > second_number):
    print(f'O maior número entre {first_number}')
else:
    print(f'O maior número entre {second_number}')
    